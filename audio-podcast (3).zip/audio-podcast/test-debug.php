<?php $test = "hello"
